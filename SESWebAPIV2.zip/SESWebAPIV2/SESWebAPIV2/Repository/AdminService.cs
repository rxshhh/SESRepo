﻿using Microsoft.Extensions.Logging;
using SESWebAPIV2.Models;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace SESWebAPIV2.Repository
{
    public class AdminService : IAdmin
    {
        private readonly MatchContext _context;
        private readonly ILogger<AdminService> _logger;
        private readonly IToken _tokenService;

        public AdminService(MatchContext context, ILogger<AdminService> logger, IToken tokenService)
        {
            _context = context;
            _logger = logger;
            _tokenService = tokenService;
        }

        public AdminLoginDTO Login(AdminLoginDTO admin)
        {
            var dbAdmin = _context.Admins.FirstOrDefault(adm => adm.Username == admin.Username);
            if (dbAdmin == null)
                return null;
            HMACSHA512 hmac = new HMACSHA512(dbAdmin.PassKey);
            byte[] adminPass = hmac.ComputeHash(Encoding.UTF8.GetBytes(admin.Password));
            for (int i = 0; i < adminPass.Length; i++)
            {
                if (adminPass[i] != dbAdmin.Password[i])
                    return null;
            }
            admin.Token = _tokenService.GenerateToken(admin);
            admin.Password = "";
            return admin;
        }

        public AdminLoginDTO Register(AdminDTO admin)
        {
            Admin dbAdmin = new Admin();
            HMACSHA512 hmac = new HMACSHA512();
            dbAdmin.FullName = admin.FullName;
            dbAdmin.Phone = admin.Phone;
            dbAdmin.Age = admin.Age;
            dbAdmin.Username = admin.Username;
            dbAdmin.PassKey = hmac.Key;
            dbAdmin.Password = hmac.ComputeHash(Encoding.UTF8.GetBytes(admin.Password));
            _context.Admins.Add(dbAdmin);
            try
            {
                _context.SaveChanges();
                AdminLoginDTO myAdmin = new AdminLoginDTO()
                {
                    Username = admin.Username
                };
                myAdmin.Token = _tokenService.GenerateToken(myAdmin);
                return myAdmin;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message + " " + DateTime.Now);
            }
            return null;
        }
    }
}
