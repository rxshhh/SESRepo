﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SESWebAPIV2.Models;

namespace SESWebAPIV2.Repository
{
    public class TeamRepository : ITeamRepository<int, Team>
    {
        private readonly MatchContext _context;
        private readonly ILogger<MatchRepository> _logger;

        public TeamRepository(MatchContext context, ILogger<MatchRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<Team> Add(Team item)
        {
            try
            {
                _context.Teams.Add(item);
                await _context.SaveChangesAsync();
                return item;
            }
            catch (Exception exception)
            {
                _logger.LogError(exception.Message);
                _logger.LogError("----" + DateTime.Now.ToString());
            }
            return null;
        }

        public async Task<Team> Delete(int key)
        {
            try
            {
                var item = await Get(key);
                _context.Teams.Remove(item);
                await _context.SaveChangesAsync();
                return item;
            }
            catch (Exception e)
            {
                _logger.LogError("Error in Deleting Team");
            }
            return null;
        }

        public async Task<Team> Get(int key)
        {
            try
            {
                var item = _context.Teams.FirstOrDefault(p => p.TeamId == key);
                return item;
            }
            catch (Exception e)
            {
                _logger.LogError("Error in Displaying Team");
            }
            return null;
        }

        public async Task<ICollection<Team>> GetAll()
        {
            return _context.Teams.ToList();
        }

        public async Task<Team> Update(Team item)
        {
            try
            {
                var player = await Get(item.TeamId);
                // DO NOT ADD ID
                //player.FullName = item.FullName;
                //player.JerseyNumber = item.JerseyNumber;
                //player.FieldPosition = item.FieldPosition;
                // Double check the teamName attribute
                await _context.SaveChangesAsync();
                return item;
            }
            catch (Exception e)
            {
                _logger.LogError("Error in Updating Team");
            }
            return null;
        }
    }
}
