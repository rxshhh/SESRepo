﻿using System;
namespace SESWebAPIV2.Models
{
    public class AdminLoginDTO
    {
        // Upon signing up, admin will receive a jwt token
        public string Username { get; set; }

        public string Password { get; set; }

        public string Token { get; set; }
    }
}
