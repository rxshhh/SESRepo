﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SESWebAPIV2.Models
{
    public class Field
    {
        [Key]
        public int FieldId { get; set; }

        public string FieldName { get; set; }

        public string FieldCity { get; set; }

        [ForeignKey("MatchId")]
        public int MatchId { get; set; }
        public virtual Match Match { get; set; }

        public virtual ICollection<Match> Matches { get; set; }
    }
}
