﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SESWebAPIV2.Models
{
    public class Booking
    {
        [Key]
        public int BookingId { get; set; }

        public string MatchName { get; set; }

        public float Price { get; set; }

        public int Quantity { get; set; }

        public float TotalPrice { get; set; }

        [ForeignKey("MatchId")]
        public int MatchId { get; set; }
        public virtual Match Match { get; set; }

    }
}
