﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SESWebAPIV2.Models;
using SESWebAPIV2.Repository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkTeamName=397860

namespace SESWebAPIV2.APIServices
{
    [Route("api/[controller]")]
    [ApiController]
    public class MatchController : ControllerBase
    {
        private readonly IMatchRepository<int, Match> _repository;

        public MatchController(IMatchRepository<int, Match> Repository)
        {
            _repository = Repository;
        }
        [HttpGet]
        public async Task<ActionResult<List<Match>>> GetAll()
        {
            var matches = await _repository.GetAll();
            return matches.ToList();
        }
        [HttpPost]
        public async Task<ActionResult<Match>> Post(Match match)
        {
            return await _repository.Add(match);
        }
        [HttpGet]
        [Route("GetMatchByID/{id}")]
        public async Task<ActionResult<Match>> Get(int id)
        {
            return await _repository.Get(id);
        }

        [HttpPut]
        public async Task<ActionResult<Match>> Update(Match match)
        {
            return await _repository.Update(match);

        }
        [HttpDelete]
        public async Task<ActionResult<Match>> Delete(int id)
        {
            //await _repository.Delete(id);
            return await _repository.Delete(id);
        }
    }
}
